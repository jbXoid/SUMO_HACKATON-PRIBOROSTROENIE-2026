#ifndef PERIMETER_h
#define PERIMETER_h
//-------------------���������--------------------------------------------------------------------------------
#ifdef FK63

#endif //FK63

#ifdef FK35


#endif //FK35

#ifdef JS400

#endif //JS400
//-----------------------------------------------------------------------------------------------------------

extern void ProcessFSM_PERIMETER (void);
#endif
